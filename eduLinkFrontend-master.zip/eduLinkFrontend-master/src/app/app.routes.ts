import { Routes } from '@angular/router';
import { StudentDashboardComponent } from './component/student-dashboard-component/student-dashboard-component';
import { LandingPageComponent } from './component/landing-page-component/landing-page-component';
import { HomeComponent } from './component/home-component/home-component';
import { LoginComponent } from './component/login-component/login-component';
import { CourseDetailContainerComponent } from './component/course-detail-container-component/course-detail-container-component';
import { FacultyDashboardComponent } from './component/faculty-dashboard-component/faculty-dashboard-component';
import { SignupChoice } from './auth/signup-choice/signup-choice';
import { FacultyCourseComponent } from './component/faculty-course-component/faculty-course-component';
import { FacultyProfileComponent } from './component/faculty-profile-component/faculty-profile-component';
import { CourseContentComponent } from './component/course-content-component/course-content-component';
import { CreateCourseComponent } from './component/create-course-component/create-course-component';
import { UploadMaterialComponent } from './component/upload-material.component/upload-material.component';

export const routes: Routes = [
  {
    path: '', component: LandingPageComponent,
    children: [
      { path: '', component: HomeComponent },
      { path: 'login', component: LoginComponent },
      { path: 'signup', component: SignupChoice },
      { path: 'course-detail/:id', component: CourseDetailContainerComponent },
      { path: 'signup/student', loadComponent: () => import('./auth/student-signup/student-signup').then(m => m.StudentSignup) },
      { path: 'signup/faculty', loadComponent: () => import('./auth/faculty-signup/faculty-signup').then(m => m.FacultySignup) }

    ]
  },
  {
    path: 'student-dashboard', component: StudentDashboardComponent,
    children: [
      { path: '', loadComponent: () => import('./component/student-home-component/student-home-component').then(m => m.StudentHomeComponent) },
      { path: 'myProfile', loadComponent: () => import('./component/student-profile-component/student-profile-component').then(m => m.StudentProfileComponent) },
      { path: 'myCourses', loadComponent: () => import('./component/student-enrolled-course-component/student-enrolled-course-component').then(m => m.StudentEnrolledCourseComponent) },
      { path: 'myAttendance', loadComponent: () => import('./component/attendance-card-component/attendance-card-component').then(m => m.AttendanceCardComponent) },
      { path: 'submitFeedback', loadComponent: ()=> import('./component/feedback-form-component/feedback-form-component').then(m=>m.FeedbackFormComponent)},
      { path: 'myGrades', loadComponent: () => import('./component/grade-component/grade-component').then(m => m.GradeComponent) }
    ]
  },
{ 
    path: 'create-course', 
    component: CreateCourseComponent,
  },
    {path:'upload-material/:id', component: UploadMaterialComponent},
  { path: 'course-content/:id', component: CourseContentComponent },
  { path: 'create-course', component: CreateCourseComponent },
  {
    path: 'faculty-dashboard', component: FacultyDashboardComponent,
    children: [
      { path: '', loadComponent: () => import('./component/faculty-home-component/faculty-home-component').then(m => m.FacultyHomeComponent) },
      { path: 'myProfile', component: FacultyProfileComponent },
      { path: 'myCourses', component: FacultyCourseComponent },
    ]
  },
   { path: '**', redirectTo: '' }
];
