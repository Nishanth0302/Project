import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FacultySignUpDto } from '../../model/FacultySignUpDto.model';
import { FacultyService } from '../../service/faculty-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-faculty-signup',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './faculty-signup.html',
  styleUrl: './faculty-signup.css',
})
export class FacultySignup implements OnInit {

  facultyForm!: FormGroup;
  genders = ['Male', 'Female', 'Other'];

  constructor(
    private fb: FormBuilder,
    private facultyService: FacultyService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.facultyForm = this.fb.group({
      userName: ['', Validators.required],

      userEmail: ['', [Validators.required, Validators.email]],

      phoneNumber: [
        null,
        [
          Validators.required,
          Validators.min(1000000000),
          Validators.max(9999999999)
        ]
      ],

      facultyGender: ['', Validators.required],

      facultyAddress: ['', Validators.required],

      facultyYearOfExperience: [
        null,
        [
          Validators.required,
          Validators.min(0),
          Validators.max(60)
        ]
      ],

      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(20),
          Validators.pattern(
            /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/
          )
        ]
      ]
    });
  }

  registerFaculty(): void {
    if (this.facultyForm.invalid) {
      this.facultyForm.markAllAsTouched();
      return;
    }

    const payload: FacultySignUpDto = this.facultyForm.value;

    this.facultyService.registerFaculty(payload).subscribe({
      next: (res) => {
        alert(res);

        
        this.router.navigate(['/login']);

        this.facultyForm.reset();
      },
      error: (err) => {
        console.error(err);
        alert('Faculty registration failed');
      }
    });
  }


isFieldInvalid(fieldName: string): boolean {
  const field = this.facultyForm.get(fieldName);
  return !!(field && field.invalid && (field.dirty || field.touched));
}

hasError(fieldName: string, errorType: string): boolean {
  const field = this.facultyForm.get(fieldName);
  return !!(field && field.hasError(errorType) && (field.dirty || field.touched));
}

getPasswordErrorMessage(): string {
  const field = this.facultyForm.get('password');
  if (!field || !field.errors || (!field.dirty && !field.touched)) {
    return '';
  }

  if (field.hasError('required')) {
    return 'Password is required';
  }
  if (field.hasError('minlength')) {
    return 'Password must be at least 8 characters';
  }
  if (field.hasError('maxlength')) {
    return 'Password must not exceed 20 characters';
  }
  if (field.hasError('pattern')) {
    return 'Password must contain uppercase, lowercase, number and special character (@#$%^&+=)';
  }
  return '';
}

getPhoneErrorMessage(): string {
  const field = this.facultyForm.get('phoneNumber');
  if (!field || !field.errors || (!field.dirty && !field.touched)) {
    return '';
  }

  if (field.hasError('required')) {
    return 'Phone number is required';
  }
  if (field.hasError('min') || field.hasError('max')) {
    return 'Phone number must be exactly 10 digits';
  }
  return '';
}

}