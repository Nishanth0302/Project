import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-signup-choice',
  imports: [RouterLink],
  templateUrl: './signup-choice.html',
  styleUrl: './signup-choice.css',
})
export class SignupChoice {}
