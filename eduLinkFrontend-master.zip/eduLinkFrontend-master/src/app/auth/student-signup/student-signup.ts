import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { StudentService } from '../../service/student-service';
import { StudentSignUpDto } from '../../model/StudentSignUpDto.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-signup',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './student-signup.html',
  styleUrl: './student-signup.css'
})
export class StudentSignup implements OnInit {

  studentForm!: FormGroup;
  genders = ['Male', 'Female', 'Other', 'Prefer not to say'];

  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.studentForm = this.fb.group({
      userName: ['', Validators.required],

      userEmail: ['', [Validators.required, Validators.email]],

      phoneNumber: [
        null,
        [
          Validators.required,
          Validators.min(1000000000),
          Validators.max(9999999999)
        ]
      ],

      studentDOB: ['', Validators.required],

      studentGender: ['', Validators.required],

      studentAddress: ['', Validators.required],

      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(20),
          Validators.pattern(
            /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/
          )
        ]
      ]
    });
  }

  registerStudent(): void {
    if (this.studentForm.invalid) {
      this.studentForm.markAllAsTouched();
      return;
    }

    const payload: StudentSignUpDto = this.studentForm.value;

    this.studentService.studentRegistration(payload).subscribe({
      next: (res) => {
        alert(res);
        this.studentForm.reset();
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error(err);
        alert('Student registration failed');
      }
    });
  }

  // Helper method to check if field has error and is touched
  hasError(fieldName: string, errorType: string): boolean {
    const field = this.studentForm.get(fieldName);
    return !!(field && field.hasError(errorType) && (field.dirty || field.touched));
  }

  // Helper method to check if field is invalid and touched
  isFieldInvalid(fieldName: string): boolean {
    const field = this.studentForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  // Get error message for password field
  getPasswordErrorMessage(): string {
    const field = this.studentForm.get('password');
    if (!field || !field.errors || (!field.dirty && !field.touched)) {
      return '';
    }

    if (field.hasError('required')) {
      return 'Password is required';
    }
    if (field.hasError('minlength')) {
      return 'Password must be at least 8 characters';
    }
    if (field.hasError('maxlength')) {
      return 'Password must not exceed 20 characters';
    }
    if (field.hasError('pattern')) {
      return 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character (@#$%^&+=)';
    }
    return '';
  }

  // Get error message for phone field
  getPhoneErrorMessage(): string {
    const field = this.studentForm.get('phoneNumber');
    if (!field || !field.errors || (!field.dirty && !field.touched)) {
      return '';
    }

    if (field.hasError('required')) {
      return 'Phone number is required';
    }
    if (field.hasError('min')) {
      return 'Phone number must be valid (at least 10 digits)';
    }
    if (field.hasError('max')) {
      return 'Phone number must be valid (at most 10 digits)';
    }
    return '';
  }
}