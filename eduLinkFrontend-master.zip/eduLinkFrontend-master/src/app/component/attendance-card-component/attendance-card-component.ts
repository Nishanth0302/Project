import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // Required for [disabled]
import { AttendanceService } from '../../service/attendance-service';
import { CourseAttendanceProjection } from '../../model/CourseAttendanceProjection.model';
import { AuthService } from '../../service/auth-service';

@Component({
  selector: 'app-attendance-card-component',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './attendance-card-component.html',
  styleUrl: './attendance-card-component.css',
})
export class AttendanceCardComponent implements OnInit {
  courseAttendanceProjection: CourseAttendanceProjection[] = [];
  error = "";

  constructor(
    private attendanceService: AttendanceService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    const studentId = this.authService.getUserId();
    if (studentId) {
      this.findAttendanceDetailsByStudentId(studentId);
    }
  }

  findAttendanceDetailsByStudentId(studentId: number) {
    this.attendanceService.findAttendanceDetailsByStudentId(studentId).subscribe({
      next: (data) => {
        this.courseAttendanceProjection = data;
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.error = err.message;
        this.cdr.detectChanges();
      }
    });
  }

  // Method to check if attendance is locked (within 24 hours)
  isAttendanceDisabled(lastDate?: string): boolean {
    if (!lastDate) return false; // Never posted before

    const lastDateObj = new Date(lastDate);
    const now = new Date();
    const diffInHours = (now.getTime() - lastDateObj.getTime()) / (1000 * 60 * 60);
    
    return diffInHours < 24;
  }

  // Calculate remaining time for the tooltip
  getRemainingTime(lastDate: string): string {
    const lastDateObj = new Date(lastDate);
    const unlockDate = new Date(lastDateObj.getTime() + 24 * 60 * 60 * 1000);
    const now = new Date();
    const diffMs = unlockDate.getTime() - now.getTime();
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m left`;
  }

  postAttendance(courseId: number) {
    const studentId = this.authService.getUserId();
    if (!studentId) return;

    const dto = { studentId, courseId };
    
    this.attendanceService.registerAttendanceByStudentId(dto).subscribe({
      next: (res) => {
        alert(res);
        this.findAttendanceDetailsByStudentId(studentId); // Refresh to lock button
      },
      error: (err) => alert("Error: " + err.message)
    });
  }
}