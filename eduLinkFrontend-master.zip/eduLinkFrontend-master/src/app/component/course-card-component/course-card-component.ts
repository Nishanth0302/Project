import { Component, Input } from '@angular/core';
import { CourseProjection } from '../../model/CourseProjection.model';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-course-card-component',
  imports: [CommonModule, RouterModule],
  templateUrl: './course-card-component.html',
  styleUrl: './course-card-component.css',
})
export class CourseCardComponent {
  @Input({ required: true }) course!: CourseProjection;

  constructor(private readonly router: Router) {}

  get stars() {
    return Array(5).fill(0).map((_, i) => i < this.course.courseRating);
  }

  onViewDetails() {
    this.router.navigate(['/course-detail', this.course.courseId]);
  }

  onJoin() {
    this.router.navigate(['/course-detail', this.course.courseId]);
  }
}