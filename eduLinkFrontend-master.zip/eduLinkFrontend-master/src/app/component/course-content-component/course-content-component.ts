import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { LearningMaterialsComponent } from '../learning-materials-component/learning-materials-component';
import { HeaderComponent } from '../header-component/header-component';
import { FooterComponent } from '../footer-component/footer-component';
import { AttendanceService } from '../../service/attendance-service'; // Import this
import { AuthService } from '../../service/auth-service'; // Import this

@Component({
  selector: 'app-course-content-component',
  standalone: true,
  imports: [CommonModule, LearningMaterialsComponent, HeaderComponent, FooterComponent],
  templateUrl: './course-content-component.html',
  styleUrl: './course-content-component.css'
})
export class CourseContentComponent implements OnInit {
  courseId: number | null = null;
  isLocked = false;
  isStudent = false;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly attendanceService: AttendanceService,
    private readonly authService: AuthService
  ) {}

  ngOnInit() {
    // 1. Determine if user is a student (Faculty shouldn't mark attendance)
    this.isStudent = this.authService.getRole() === 'STUDENT';

    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.courseId = Number(id);
        // 2. Only check status if the user is a student
        if (this.isStudent) {
          this.checkAttendanceStatus();
        }
      }
    });
  }

  checkAttendanceStatus() {
    const studentId = this.authService.getUserId();
    if (!studentId || !this.courseId) return;

    this.attendanceService.findAttendanceDetailsByStudentId(studentId).subscribe({
      next: (records) => {
        // Find the record for THIS specific course
        const currentRecord = records.find(r => r.courseId === this.courseId);
        
        if (currentRecord?.lastAttendanceDate) {
          const lastDate = new Date(currentRecord.lastAttendanceDate).getTime();
          const now = new Date().getTime();
          // Lock if less than 24 hours (86,400,000 ms) have passed
          this.isLocked = (now - lastDate) < 86400000;
        }
      }
    });
  }

  markAttendance() {
    const studentId = this.authService.getUserId();
    if (!studentId || !this.courseId || this.isLocked) return;

    this.attendanceService.registerAttendanceByStudentId({
      studentId: studentId,
      courseId: this.courseId
    }).subscribe({
      next: (response) => {
        alert(response);
        this.checkAttendanceStatus(); // Immediately refresh status to lock button
      },
      error: (err) => alert("Error posting attendance. Please try again.")
    });
  }
}