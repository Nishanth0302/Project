import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CourseDetail } from '../../model/CourseProjection.model';
import { CourseService } from '../../service/course-service';
import { AuthService } from '../../service/auth-service'; // Injected Auth Service
import { CourseDetailViewComponent } from '../course-detail-view-component/course-detail-view-component';
import { EnrollmentService } from '../../service/enrollment-service';

@Component({
  selector: 'app-course-detail-container-component',
  imports: [CommonModule, CourseDetailViewComponent],
  templateUrl: './course-detail-container-component.html',
  styleUrl: './course-detail-container-component.css',
})
export class CourseDetailContainerComponent implements OnInit {
  course: CourseDetail | null = null;
  loading = true;
  error: string | null = null;
  
  isEnrolled: boolean = false; // Added enrollment state

  constructor(
    private readonly route: ActivatedRoute,
    private readonly courseService: CourseService,
    private readonly authService: AuthService, // Added to constructor
    private readonly cdr: ChangeDetectorRef,
    private readonly enrollmentService: EnrollmentService
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      const courseId = params.get('id');
      console.log('Course ID from route:', courseId);
      
      if (courseId) {
        this.fetchCourseDetails(Number.parseInt(courseId));
      }
    });
  }

  private fetchCourseDetails(courseId: number) {
    this.loading = true;
    this.error = null;
    console.log('Fetching course details for ID:', courseId);
    
    this.courseService.findCourseDetailsById(courseId).subscribe({
      next: (data: any) => {
        console.log('Course data received:', data);
        this.course = this.mapToCourseDetail(data);
        
        // After getting the course, check if the current user is enrolled
        const studentId = this.authService.getUserId();
        
        if (studentId) {
          this.checkEnrollmentStatus(courseId, studentId);
        } else {
          // User is not logged in, so they definitely aren't enrolled
          this.loading = false;
          this.cdr.detectChanges();
        }
      },
      error: (err) => {
        console.error('Error fetching course details:', err);
        let errorMessage = 'Failed to load course details. ';
        if (err.status === 404) errorMessage += 'Course not found.';
        else if (err.status === 0) errorMessage += 'Could not connect to server.';
        else if (err.error?.message) errorMessage += err.error.message;
        else errorMessage += 'Please try again.';
        
        this.error = errorMessage;
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  // New method to verify enrollment with the backend
  private checkEnrollmentStatus(courseId: number, studentId: number) {
  this.enrollmentService.checkEnrollment(studentId, courseId).subscribe({
    next: (enrolled: boolean) => {
      this.isEnrolled = enrolled;
      this.loading = false;
      this.cdr.detectChanges();
    },
    error: (err) => {
      console.error('Failed to check enrollment status', err);
      this.isEnrolled = false;
      this.loading = false;
      this.cdr.detectChanges();
    }
  });
}

  private mapToCourseDetail(data: any): CourseDetail {
    return {
      courseId: data.courseId,
      courseTitle: data.courseTitle,
      courseSubject: data.courseSubject,
      courseGradeLevel: data.courseGradeLevel,
      courseCredit: data.courseCredit,
      // courseDescription:data.courseDescription,
      courseStatus: data.courseStatus,
      courseRating: data.courseRating,
      facultyName: data.facultyName || 'Instructor Name',
      facultyRating: data.facultyRating || 0,
      facultyYearOfExperience: data.facultyYearOfExperience || 0,
      description: data.courseDescription || 'Course description not available',
      lastUpdated: data.lastUpdated || new Date().toLocaleDateString('en-US', { year: '2-digit', month: '2-digit' }),
      language: data.language || 'English',
      price: data.price || 0,
      reviewCount: data.reviewCount || 0,
      studentCount: data.studentCount || 0,
      videoHours: data.videoHours || 0,
      articles: data.articles || 0,
      sections: data.sections || [],
      learningOutcomes: data.learningOutcomes || [],
    };
  }
}