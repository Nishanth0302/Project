import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseDetail } from '../../model/CourseProjection.model';
import { LearningOutcomesComponent } from '../learning-outcomes-component/learning-outcomes-component';
import { EnrollCardComponent } from '../enroll-card-component/enroll-card-component';

@Component({
  selector: 'app-course-detail-view-component',
  imports: [
    CommonModule, 
    LearningOutcomesComponent, 
    EnrollCardComponent
  ],
  templateUrl: './course-detail-view-component.html',
  styleUrl: './course-detail-view-component.css',
})
export class CourseDetailViewComponent {
  @Input({ required: true }) course!: CourseDetail;
  @Input() isEnrolled: boolean = false; // Receives state from Container
  
  hasEntered: boolean = false; // Tracks if they unlocked the view

  onCourseEntered() {
    this.hasEntered = true;
  }
}