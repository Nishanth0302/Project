import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { CourseProjection } from '../../model/CourseProjection.model';
import { CourseService } from '../../service/course-service';
import { CourseCardComponent } from "../course-card-component/course-card-component";

@Component({
  selector: 'app-course-list-component',
  standalone: true,
  imports: [CourseCardComponent],
  templateUrl: './course-list-component.html',
  styleUrl: './course-list-component.css',
})
export class CourseListComponent implements OnInit {
  courseListProjection: CourseProjection[] = [];
  error: string = '';
  
  // Track how many courses are currently visible (starts at 4)
  visibleCount: number = 4;

  constructor(
    private courseService: CourseService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.findAllAvailableCourse();
  }

  findAllAvailableCourse() {
    this.courseService.findAllAvailableCourse().subscribe({
      next: (data) => {
        this.courseListProjection = data;
        this.cdr.detectChanges();
      },
      error: (e) => {
        this.error = e.message;
        this.cdr.detectChanges();
      }
    });
  }

  // Helper method to slice the array for the HTML
  get displayedCourses(): CourseProjection[] {
    return this.courseListProjection.slice(0, this.visibleCount);
  }

  // Adds 4 more courses to the view
  showMore() {
    if (this.visibleCount < this.courseListProjection.length) {
      this.visibleCount += 4;
    }
  }

  // Removes 4 courses from the view (but never goes below 4)
  showLess() {
    if (this.visibleCount > 4) {
      this.visibleCount -= 4;
    }
  }
}