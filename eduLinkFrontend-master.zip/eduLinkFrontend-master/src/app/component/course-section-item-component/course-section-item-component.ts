import { Component, Input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseSection } from '../../model/CourseProjection.model';

@Component({
  selector: 'app-course-section-item-component',
  imports: [CommonModule],
  templateUrl: './course-section-item-component.html',
  styleUrl: './course-section-item-component.css',
})
export class CourseSectionItemComponent {
  @Input({ required: true }) section!: CourseSection;
  isExpanded = signal(false);

  toggleExpanded() {
    this.isExpanded.update(value => !value);
  }
}
