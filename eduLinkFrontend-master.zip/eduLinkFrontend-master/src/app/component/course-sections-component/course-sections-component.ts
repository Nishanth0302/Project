import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseSection } from '../../model/CourseProjection.model';
import { CourseSectionItemComponent } from '../course-section-item-component/course-section-item-component';

@Component({
  selector: 'app-course-sections-component',
  imports: [CommonModule, CourseSectionItemComponent],
  templateUrl: './course-sections-component.html',
  styleUrl: './course-sections-component.css',
})
export class CourseSectionsComponent {
  @Input({ required: true }) sections: CourseSection[] = [];
}
