import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, Location } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../service/auth-service';
import { CourseService } from '../../service/course-service';

@Component({
  selector: 'app-create-course',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './create-course-component.html',
  styleUrl: './create-course-component.css'
})
export class CreateCourseComponent implements OnInit {
  courseForm!: FormGroup;
  isSubmitting = false;
  error: string | null = null;
  success: string | null = null;

  // Options for the dropdowns
  gradeOptions = ['9', '10', '11', '12', 'K', 'Undergrad'];

  constructor(
    private readonly fb: FormBuilder,
    private readonly authService: AuthService,
    private readonly courseService: CourseService,
    private readonly router: Router,
    private readonly location: Location
  ) {}

  ngOnInit(): void {
    const facultyId = this.authService.getUserId();

    if (!facultyId) {
      alert('Please log in as faculty to create a course');
      this.router.navigate(['/login']);
      return;
    }

    // Initialize the reactive form with the facultyId
    this.initForm(facultyId);
  }

  private initForm(facultyId: number): void {
    this.courseForm = this.fb.group({
      courseTitle: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
      courseSubject: ['', [Validators.required]],
      courseGradeLevel: ['', [Validators.required]], // Starts empty to force selection
      courseCredit: [1, [Validators.required, Validators.min(1), Validators.max(10)]],
      courseDescription: ['', [Validators.required, Validators.minLength(20)]],
      facultyId: [facultyId, [Validators.required]] // Hidden piece of data for the API
    });
  }

  onSubmit(): void {
    // Check if the Reactive Form is valid
    if (this.courseForm.invalid || this.isSubmitting) {
      this.markFormGroupTouched(this.courseForm);
      this.error = "Please fill in all required fields correctly.";
      return;
    }

    this.isSubmitting = true;
    this.error = null;
    this.success = null;

    // Send the courseForm.value directly (it matches your DTO structure)
    this.courseService.registerCourse(this.courseForm.value).subscribe({
      next: (response) => {
        this.success = 'Course created successfully!';
        console.log('API Response:', response);
        
        // Navigate back to dashboard after a short delay
        setTimeout(() => {
          this.router.navigate(['/faculty-dashboard']);
        }, 1500);
      },
      error: (err) => {
        this.isSubmitting = false;
        console.error('Error creating course:', err);
        this.error = err.error || 'Failed to create course. Please try again.';
      }
    });
  }

  onCancel(): void {
    // If the form has been typed in (dirty), ask for confirmation
    if (this.courseForm.dirty) {
      const confirmDiscard = confirm('You have unsaved changes. Are you sure you want to discard them?');
      if (confirmDiscard) {
        this.location.back();
      }
    } else {
      this.location.back();
    }
  }

  // Helper to highlight errors if the user tries to submit an empty form
  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
    });
  }
}