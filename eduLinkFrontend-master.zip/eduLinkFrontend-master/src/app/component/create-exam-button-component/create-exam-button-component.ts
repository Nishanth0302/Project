import { Component } from '@angular/core';

@Component({
  selector: 'app-create-exam-button-component',
  imports: [],
  templateUrl: './create-exam-button-component.html',
  styleUrl: './create-exam-button-component.css',
})
export class CreateExamButtonComponent {}
