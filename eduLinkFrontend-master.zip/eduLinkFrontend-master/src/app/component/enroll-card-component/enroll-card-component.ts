import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CourseDetail } from '../../model/CourseProjection.model';
import { CourseService } from '../../service/course-service';
import { AuthService } from '../../service/auth-service';

@Component({
  selector: 'app-enroll-card-component',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './enroll-card-component.html',
  styleUrl: './enroll-card-component.css',
})
export class EnrollCardComponent {
  @Input({ required: true }) course!: CourseDetail;
  @Input() isEnrolled: boolean = false; 
  
  @Output() enrollmentCompleted = new EventEmitter<void>(); 

  isEnrolling: boolean = false;
  error="";

  constructor(
    private readonly courseService: CourseService,
    private readonly authService: AuthService,
    private readonly router: Router 
  ) {}

  onEnterClick() {
    this.router.navigate(['/course-content', this.course.courseId]);
  }

  onEnrollClick() {
    const studentId = this.authService.getUserId();
    
    if (!studentId) {
      alert('Please log in to enroll in this course');
      this.router.navigate(['/login']);
      return;
    }

    this.isEnrolling = true;
    
    this.courseService.enrollCourse(this.course.courseId, studentId).subscribe({
      next: () => {
        this.isEnrolling = false;
        this.isEnrolled = true; 
        this.enrollmentCompleted.emit(); 
        alert(`Successfully enrolled in ${this.course.courseTitle}`);
      },
      error: (err) => {
        this.isEnrolling = false;
        this.error = err.message;
        console.error('Enrollment error:', err);
        alert('Failed to enroll. Please try again.');
      }
    });
  }
}