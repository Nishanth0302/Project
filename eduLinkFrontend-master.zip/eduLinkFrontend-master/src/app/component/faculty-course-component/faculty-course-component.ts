import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // Required for @for and @if
import { CourseService } from '../../service/course-service';
import { CourseProjection } from '../../model/CourseProjection.model';
import { AuthService } from '../../service/auth-service';
import { RouterLink } from "@angular/router"; // Import your card component

@Component({
  selector: 'app-faculty-course-component',
  standalone: true,
  imports: [CommonModule, RouterLink], // Added essential imports
  templateUrl: './faculty-course-component.html',
  styleUrl: './faculty-course-component.css',
})
export class FacultyCourseComponent implements OnInit {
  courseProjection: CourseProjection[] = [];
  error: string = '';
  isLoading: boolean = false;
  isEditMode: boolean = false;

  constructor(
    private readonly courseService: CourseService,
    private readonly authService: AuthService,
    private readonly cdr: ChangeDetectorRef
  ) {}
  toggleEditMode() {
    this.isEditMode = !this.isEditMode;
  }
  handleDeleteCourse(courseId: number) {
    if (confirm('Are you sure you want to delete this course?')) {
      this.courseService.deleteCourse(courseId).subscribe({
        next: (res) => {
          this.courseProjection = this.courseProjection.filter(c => c.courseId !== courseId);
          this.cdr.detectChanges();
        },
        error: (err) => alert('Delete failed: Course might have active students.')
      });
    }
  }
  ngOnInit() {
    const facultyId = this.authService.getUserId();
    if (facultyId) {
      this.getCoursesByFacultyId(facultyId);
    } else {
      this.error = 'Faculty session expired. Please log in again.';
      this.cdr.detectChanges();
    }
  }

  getCoursesByFacultyId(facultyId: number) {
    this.isLoading = true;
    this.courseService.getCoursesByFacultyId(facultyId).subscribe({
      next: (data) => {
        this.courseProjection = data;
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: (e) => {
        this.error = 'Failed to load courses: ' + e.message;
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  /**
   * Handles the deletion of a course
   * @param courseId The unique identifier of the course to remove
   */
  
}