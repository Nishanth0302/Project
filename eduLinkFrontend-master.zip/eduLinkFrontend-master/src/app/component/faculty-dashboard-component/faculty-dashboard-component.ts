import { Component } from '@angular/core';
import { HeaderComponent } from "../header-component/header-component";
import { FooterComponent } from "../footer-component/footer-component";
import { RouterOutlet } from "@angular/router";
import { FacultySideComponent } from "../faculty-side-component/faculty-side-component";

@Component({
  selector: 'app-faculty-dashboard-component',
  imports: [HeaderComponent, FooterComponent, RouterOutlet, FacultySideComponent],
  templateUrl: './faculty-dashboard-component.html',
  styleUrl: './faculty-dashboard-component.css',
})
export class FacultyDashboardComponent {}
