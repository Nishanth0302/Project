import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FacultyCourseComponent } from "../faculty-course-component/faculty-course-component";
import { AuthService } from '../../service/auth-service';
import { CourseService } from '../../service/course-service';
import { FeedbackService } from '../../service/feedback-service';

@Component({
  selector: 'app-faculty-home-component',
  standalone: true,
  imports: [FacultyCourseComponent, CommonModule, RouterLink],
  templateUrl: './faculty-home-component.html',
  styleUrl: './faculty-home-component.css',
})
export class FacultyHomeComponent implements OnInit {
  
  // --- UI State Variables ---
  facultyCourseCount = 0;
  totalStudents = 0;
  // upcomingExamsCount REMOVED
  error = "";
  recentFeedbacks: any[] = []; 

  // upcomingExams ARRAY REMOVED completely from here

  constructor(
    private courseService: CourseService,
    private feedbackService: FeedbackService,
    private authService: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    const facultyId = this.authService.getUserId();
    
    if (facultyId) {
      this.getFacultyCourseCount(facultyId);
      this.getTotalStudents(facultyId);
      this.loadRecentFeedback();
    }
  }

  getFacultyCourseCount(facultyId: number) {
    this.courseService.getFacultyCourseCount(facultyId).subscribe({
      next: (data) => {
        this.facultyCourseCount = data;
        this.cdr.detectChanges();
      },
      error: (e) => {
        this.error = e.message;
        this.cdr.detectChanges();
      }
    });
  }

  getTotalStudents(facultyId: number) {
    this.totalStudents = 128; // Placeholder
  }

  createCourse() {
    this.router.navigate(['/create-course']);
  }

  loadRecentFeedback() {
    const userId = Number(this.authService.getUserId());
    
    if (!userId) return;

    this.feedbackService.findFeedBackList().subscribe({
      next: (allFeedback: any[]) => {
        // Filter is back! It will now successfully match the IDs.
        const userFeedback = allFeedback.filter(
          (f) => f.appUserRoleId === userId
        );
        
        // Grab the 4 most recent
        this.recentFeedbacks = userFeedback.slice(0, 4); 
        this.cdr.detectChanges(); 
      },
      error: (err) => {
        console.error('Could not load feedback', err);
        this.error = "Could not load recent feedback.";
        this.cdr.detectChanges();
      }
    });
  }
}