import { Component, signal } from '@angular/core';
import { FacultyService } from '../../service/faculty-service';
import { AuthService } from '../../service/auth-service';
import { FacultyDetailByIdDto } from '../../model/FacultyDetailByIdDto.model';

@Component({
  selector: 'app-faculty-profile-component',
  imports: [],
  templateUrl: './faculty-profile-component.html',
  styleUrl: './faculty-profile-component.css',
})
export class FacultyProfileComponent {

  facultyDetailByIdDto = signal<FacultyDetailByIdDto | null>(null);
  error ="";

  constructor(private facultyService: FacultyService,
    private authService: AuthService){}

  ngOnInit() {
    const facultyId = this.authService.getUserId();
    if (facultyId === null) return;
    this.facultyService.getFacultyDetailsByFacultyId(facultyId).subscribe({
      next:(data)=>{
        this.facultyDetailByIdDto.set(data);
        console.log(this.facultyDetailByIdDto()?.facultyAddress);
      },
      error:(err)=>{
        this.error=err.message;
      }
    });
  }

}
