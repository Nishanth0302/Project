import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-faculty-side-component',
  imports: [RouterLink],
  templateUrl: './faculty-side-component.html',
  styleUrl: './faculty-side-component.css',
})
export class FacultySideComponent {}
