import { Component, Input } from '@angular/core';
import { FeedbackProjection } from '../../model/FeedbackProjection.model';

@Component({
  selector: 'app-feedback-card-component',
  imports: [],
  templateUrl: './feedback-card-component.html',
  styleUrl: './feedback-card-component.css',
})
export class FeedbackCardComponent {
  @Input({ required: true }) feedback!: FeedbackProjection;
  
  getInitials(name: string): string {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  }
  get stars() {
    return Array(5).fill(0).map((_, i) => i < this.feedback.rating);
  }
}
