// feedback-form.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, Location } from '@angular/common';
import { FeedbackService } from '../../service/feedback-service';
import { AuthService } from '../../service/auth-service';
import { FeedbackDto } from '../../model/FeedbackDto';

@Component({
  selector: 'app-feedback-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './feedback-form-component.html'
})
export class FeedbackFormComponent implements OnInit {
  feedbackForm!: FormGroup;
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    private feedbackService: FeedbackService,
    private authService: AuthService,
    public location: Location
  ) {}

  ngOnInit() {
    this.feedbackForm = this.fb.group({
      // Matches @DecimalMin(1.0) and @DecimalMax(5.0)
      rating: [5, [Validators.required, Validators.min(1), Validators.max(5)]],
      // Matches @Size(min = 10, max = 500)
      comment: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(500)]]
    });
  }

  onSubmit() {
  if (this.feedbackForm.valid) {
    this.isSubmitting = true;

    // Use the nullish coalescing operator (??) to ensure a number is always sent
    const feedbackRequest: FeedbackDto = {
      appUserRoleId: this.authService.getUserId() ?? 0, 
      reviewerType: this.authService.getRole() ?? 'STUDENT',
      rating: this.feedbackForm.value.rating,
      comment: this.feedbackForm.value.comment
    };

    this.feedbackService.registerFeedback(feedbackRequest).subscribe({
      next: (response) => {
        alert(response);
        this.location.back();
      },
      error: (err) => {
        console.error(err);
        this.isSubmitting = false;
      }
    });
  }
}
}