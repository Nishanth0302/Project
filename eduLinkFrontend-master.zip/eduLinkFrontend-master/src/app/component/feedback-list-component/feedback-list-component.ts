import { Component,ChangeDetectorRef } from '@angular/core';
import { FeedbackProjection } from '../../model/FeedbackProjection.model';
import { FeedbackService } from '../../service/feedback-service';
import { FeedbackCardComponent } from '../feedback-card-component/feedback-card-component';

@Component({
  selector: 'app-feedback-list-component',
  imports: [FeedbackCardComponent],
  templateUrl: './feedback-list-component.html',
  styleUrl: './feedback-list-component.css',
})
export class FeedbackListComponent {
  feedbackList:FeedbackProjection[] =[];
  error: string= '';
  constructor(private feedbackService:FeedbackService,private cdr: ChangeDetectorRef){};

  ngOnInit(){
    this.findFeedBackList();
  }

  findFeedBackList(){
    this.feedbackService.findFeedBackList().subscribe({
      next: (data)=>{
        this.feedbackList = data,
        this.cdr.detectChanges()
      },
      error: (e)=>{
        this.error = e.message
        this.cdr.detectChanges();
      }
    });
  }
}