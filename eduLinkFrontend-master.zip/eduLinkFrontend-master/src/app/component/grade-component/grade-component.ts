import { Component, signal } from '@angular/core';
import { GradeService } from '../../service/grade-service';
import { AuthService } from '../../service/auth-service';
import { GradeDetailsByStudentIdDto } from '../../model/GradeDetailsByStudentIdDto.model';

@Component({
  selector: 'app-grade-component',
  imports: [],
  templateUrl: './grade-component.html',
  styleUrl: './grade-component.css',
})
export class GradeComponent {

  gradeDetailsByStudentIdDto = signal<GradeDetailsByStudentIdDto[]>([]);
  error="";

  constructor(private gradeService: GradeService,private authService: AuthService) {}

  ngOnInit() {
    const studentId = this.authService.getUserId();
    if(studentId==null){
      return;
    }
    this.gradeService.findAllGradesByStudentId(studentId).subscribe({
      next: (data) => {
        this.gradeDetailsByStudentIdDto.set(data);
        console.log('Grade details:', this.gradeDetailsByStudentIdDto());
      },
      error: (e) => {
        this.error = e.error.message;
      }
    });
  }
}
