import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../service/auth-service';

@Component({
  selector: 'app-header-component',
  imports: [CommonModule, RouterLink],
  templateUrl: './header-component.html',
  styleUrl: './header-component.css',
})
export class HeaderComponent implements OnInit {
  isLoggedIn = false;
  userRole: string | null = null;

  constructor(private readonly authService: AuthService, private readonly router: Router) {}

  ngOnInit() {
    this.isLoggedIn = this.authService.isLoggedIn();
    this.userRole = this.authService.getRole();
  }

  logout() {
    this.authService.logout();
    this.isLoggedIn = false;
    this.userRole = null;
  }

  navigateToDashboard() {
    if (this.userRole === 'STUDENT') {
      this.router.navigate(['/student-dashboard']);
    } else if (this.userRole === 'FACULTY') {
      this.router.navigate(['/faculty-dashboard']);
    }
  }
}
