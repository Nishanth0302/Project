import { Component } from '@angular/core';
import { CourseListComponent } from '../course-list-component/course-list-component';
import { FeedbackListComponent } from '../feedback-list-component/feedback-list-component';

@Component({
  selector: 'app-home-component',
  imports: [CourseListComponent,FeedbackListComponent],
  templateUrl: './home-component.html',
  styleUrl: './home-component.css',
})
export class HomeComponent {}
