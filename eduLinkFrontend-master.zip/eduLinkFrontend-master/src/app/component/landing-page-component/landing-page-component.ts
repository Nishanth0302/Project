import { Component, OnInit } from '@angular/core';
import { FooterComponent } from '../footer-component/footer-component';
import { HeaderComponent } from '../header-component/header-component';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { filter } from 'rxjs';

@Component({
  selector: 'app-landing-page-component',
  imports: [FooterComponent, HeaderComponent, RouterOutlet, CommonModule],
  templateUrl: './landing-page-component.html',
  styleUrl: './landing-page-component.css',
})
export class LandingPageComponent implements OnInit {
  showHeader = true;
  showFooter = true;
  private readonly noHeaderRoutes = ['/login', '/signup','/signup/student','/signup/faculty']; // added '/signup/student','/signup/faculty' so header does not show up....

  constructor(private readonly router: Router) {}

  ngOnInit() {
    // Set initial state based on current route
    this.updateLayout();
    
    // Listen to route changes
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateLayout();
      });
  }

  private updateLayout() {
    const currentUrl = this.router.url.split('?')[0]; // Remove query params
    this.showHeader = !this.noHeaderRoutes.includes(currentUrl);
    this.showFooter = true; // Always show footer
  }
}
