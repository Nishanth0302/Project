import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { OnInit } from '@angular/core';
import { OnChanges } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LearningMaterialService } from '../../service/learningmaterial-service';
import { AuthService } from '../../service/auth-service';
import { GradeService } from '../../service/grade-service';

@Component({
  selector: 'app-learning-materials-component',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './learning-materials-component.html',
  styleUrl: './learning-materials-component.css',
})
export class LearningMaterialsComponent implements OnInit, OnChanges {
  @Input({ required: true }) courseId!: number;
  
  materials: any[] = [];
  loading = false;
  error: string | null = null;
  selectedMaterialId: number | null = null;
  isFaculty = false;
  completedMaterials = new Set<number>();
  registrationResult: string | null = null;
  gradeInfo: any = null;
  isProcessing = false;

  constructor(
    private readonly learningMaterialService: LearningMaterialService,
    private readonly authService: AuthService,
    private readonly gradeService: GradeService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.isFaculty = this.authService.getRole() === 'FACULTY';
    if (this.courseId) {
      this.loadMaterials();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['courseId'] && !changes['courseId'].isFirstChange()) {
      this.loadMaterials();
    }
  }

  loadMaterials() {
  this.loading = true;
  this.error = null;
  
  this.learningMaterialService.getCourseMaterials(this.courseId).subscribe({
    next: (data: any) => {
      console.log('Materials received:', data);
      
      if (data) {
        // If data is an object (like in your screenshot), wrap it in an array
        // If it's already an array, use it as is
        this.materials = Array.isArray(data) ? data : [data];
      } else {
        this.materials = [];
      }
      
      this.loading = false;
      this.cdr.detectChanges(); 
    },
    error: (err: any) => {
      this.error = 'Failed to load course materials.';
      this.loading = false;
      this.cdr.detectChanges(); 
    }
  });
}

  // learning-materials.component.ts

downloadMaterial(material: any) {
  const idToUse = material.id; 
  
  if (!idToUse) {
    console.error("Material ID is missing!", material);
    return;
  }

  this.selectedMaterialId = idToUse;
  this.cdr.detectChanges();

  this.learningMaterialService.getLearningMaterialContent(idToUse).subscribe({
    next: (blob: Blob) => {
      // 1. Create a blob from the response [cite: 1]
      const file = new Blob([blob], { type: 'application/pdf' }); 
      
      // 2. Create a temporary URL [cite: 1]
      const url = window.URL.createObjectURL(file);
      
      // 3. Create a hidden anchor element to trigger download [cite: 1]
      const link = document.createElement('a');
      link.href = url;
      link.download = material.learningMaterialTitle || `material-${idToUse}.pdf`;
      
      // 4. Trigger the click and cleanup [cite: 1]
      link.click();
      window.URL.revokeObjectURL(url);
      
      this.selectedMaterialId = null;
      this.cdr.detectChanges();
    },
    error: (err) => {
      console.error("Download error:", err);
      this.selectedMaterialId = null;
      this.cdr.detectChanges();
    }
  });
}

viewMaterial(material: any) {
    this.selectedMaterialId = material.id;
    this.cdr.detectChanges(); 
    
    this.learningMaterialService.getLearningMaterialContent(material.id).subscribe({
      next: (blob: Blob) => {
        // Create the blob with the EXPLICIT PDF type
        const file = new Blob([blob], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(file);
        
        // Open the URL directly
        window.open(url, '_blank');
        
        this.selectedMaterialId = null;
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        alert('Failed to open material.');
        this.selectedMaterialId = null;
        this.cdr.detectChanges();
      }
    });
}

  toggleComplete(materialId: number) {
    // If already completed, just show the result
    if (this.completedMaterials.has(materialId)) {
      console.log(`Material ${materialId} already completed. Showing result.`);
      return;
    }

    this.isProcessing = true;
    const studentId = this.authService.getUserId();

    if (!studentId) {
      alert('Student ID not found. Please login again.');
      this.isProcessing = false;
      return;
    }

    // Step 1: Register grade
    this.gradeService.registerGrade({
      studentId: studentId,
      courseId: this.courseId
    }).subscribe({
      next: (response: string) => {
        console.log('Grade registration response:', response);
        this.registrationResult = response;
        this.cdr.detectChanges();

        // Step 2: Fetch total grade after registration
        this.gradeService.getTotalGrade(studentId, this.courseId).subscribe({
          next: (gradeProjection: any) => {
            console.log('Grade projection:', gradeProjection);
            this.gradeInfo = gradeProjection;
            
            // Step 3: Mark material as completed (permanent)
            this.completedMaterials.add(materialId);
            this.isProcessing = false;
            this.cdr.detectChanges();
          },
          error: (err: any) => {
            console.error('Failed to fetch grade:', err);
            alert('Failed to fetch grade information.');
            this.isProcessing = false;
            this.cdr.detectChanges();
          }
        });
      },
      error: (err: any) => {
        console.error('Grade registration failed:', err);
        alert('Failed to register grade. Please try again.');
        this.isProcessing = false;
        this.cdr.detectChanges();
      }
    });
  }
}