import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LearningOutcome } from '../../model/CourseProjection.model';

@Component({
  selector: 'app-learning-outcomes-component',
  imports: [CommonModule],
  templateUrl: './learning-outcomes-component.html',
  styleUrl: './learning-outcomes-component.css',
})
export class LearningOutcomesComponent {
  @Input({ required: true }) outcomes: LearningOutcome[] = [];
}
