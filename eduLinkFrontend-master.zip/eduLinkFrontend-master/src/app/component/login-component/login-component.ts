import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth-service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-login-component',
  imports: [CommonModule,ReactiveFormsModule,RouterLink],
  templateUrl: './login-component.html',
  styleUrl: './login-component.css',
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private readonly fb: FormBuilder,
    private readonly authService: AuthService,
    private readonly router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  private getRoleFromToken(token: string): string | null {
    try {
      const payload = token.split('.')[1];
      const decodedJson = atob(payload);
      const decodedToken = JSON.parse(decodedJson);
      return decodedToken.role;
    } catch (e) {
      return null;
    }
  }

  onSubmit() {
  // 1. Early exit if the form is invalid
  if (this.loginForm.invalid) {
    return;
  }

  // 2. Set loading state and clear any old error messages
  this.isLoading = true;
  this.errorMessage = ''; 

  this.authService.login(this.loginForm.value).subscribe({
    next: () => {
      this.isLoading = false;          
      
      const role = this.authService.getRole(); // (Or getUserRole() depending on your service)
      
      // 3. Navigate to the correct dashboard
      if (role === 'STUDENT') {
        this.router.navigate(['/student-dashboard']); // Changed from [''] to proper dashboard route
      } else if (role === 'FACULTY') {
        this.router.navigate(['/faculty-dashboard']);
      } else {
        this.errorMessage = 'Unauthorized account role. Please contact support.';
      }
    },
    error: (err) => {
      this.isLoading = false;
      
      // 4. User-friendly error handling (Fixes the raw text issue from your screenshot)
      if (err.status === 401 || err.status === 403) {
        this.errorMessage = 'Invalid email or password. Please try again.';
      } else if (err.error && err.error.message) {
        this.errorMessage = err.error.message; // Custom error string from your Spring Boot backend
      } else {
        this.errorMessage = 'Unable to connect to the server. Please try again later.';
      }
    }
  });
}
}