import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssignmentService } from '../../service/assignment.service';
import { AssignmentStatus } from '../../model/assignment.model';
// Assume you have an AuthService to get the logged-in student's ID
import { AuthService } from '../../service/auth-service'; 

@Component({
  selector: 'app-student-assignments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student-assignments-component.html',
  styleUrls: ['./student-assignments-component.css']
})
export class StudentAssignmentsComponent implements OnInit {
  @Input({ required: true }) courseId!: number;
  
  assignments: AssignmentStatus[] = [];
  studentId!: number;
  canTakeExam: boolean = false;
  loading: boolean = false;

  constructor(
    private assignmentService: AssignmentService,
    private authService: AuthService // Getting current user ID
  ) {}

  ngOnInit() {
    // Use getUserId() instead, and fallback to 0 if it returns null
    this.studentId = this.authService.getUserId() || 0; 
    
    if (this.studentId > 0) {
      this.loadAssignments();
      this.checkExamStatus();
    } else {
      console.error("User ID not found in token!");
    }
  }

  loadAssignments() {
    this.loading = true;
    this.assignmentService.getAssignments(this.courseId, this.studentId).subscribe({
      next: (data) => {
        this.assignments = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to load assignments', err);
        this.loading = false;
      }
    });
  }

  checkExamStatus() {
    this.assignmentService.checkExamAccess(this.courseId, this.studentId).subscribe({
      next: (access) => this.canTakeExam = access,
      error: (err) => console.error('Failed to check exam access', err)
    });
  }

  markAsComplete(assignment: AssignmentStatus) {
    // Optimistic UI update (optional, makes UI feel faster)
    assignment.completed = true; 

    this.assignmentService.completeAssignment(assignment.assignmentId, this.studentId).subscribe({
      next: () => {
        // Every time they complete one, check if it unlocked the exam!
        this.checkExamStatus();
      },
      error: (err) => {
        console.error('Failed to mark complete', err);
        assignment.completed = false; // Revert on failure
      }
    });
  }

  startExam() {
    if (this.canTakeExam) {
      console.log('Routing to exam portal...');
      // e.g., this.router.navigate(['/exam', this.courseId]);
    }
  }
}