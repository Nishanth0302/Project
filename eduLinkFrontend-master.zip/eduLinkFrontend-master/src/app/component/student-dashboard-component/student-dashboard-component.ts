import { Component } from '@angular/core';
import { StudentSideComponent } from "../student-side-component/student-side-component";

import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header-component/header-component';
import { FooterComponent } from '../footer-component/footer-component';

@Component({
  selector: 'app-student-dashboard-component',
  imports: [StudentSideComponent, RouterOutlet, HeaderComponent, FooterComponent],
  templateUrl: './student-dashboard-component.html',
  styleUrl: './student-dashboard-component.css',
})
export class StudentDashboardComponent {
}
