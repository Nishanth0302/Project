import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseDetailProjection } from '../../model/CourseDetailProjection.model';
import { CourseService } from '../../service/course-service';
import { AuthService } from '../../service/auth-service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-student-enrolled-course-component',
  imports: [CommonModule],
  templateUrl: './student-enrolled-course-component.html',
  styleUrl: './student-enrolled-course-component.css',
})
export class StudentEnrolledCourseComponent implements OnInit {
  showAll: boolean = false;
  error ="";
  courseDetailProjection:CourseDetailProjection[] = [];
  
  
  constructor(
    private courseService: CourseService,
    private authService: AuthService,
    private cdr: ChangeDetectorRef,
    private router: Router
  ) {}


  toggleViewAll() {
    this.showAll = !this.showAll;
  }

  get displayedCourses() {
    return this.showAll ? this.courseDetailProjection : this.courseDetailProjection.slice(0, 6);
  }

  ngOnInit() {
    const studentId = this.authService.getUserId();
    
    if (studentId) {
      this.courseService.findCourseListByStudentId(studentId).subscribe({
        next: (data) =>{
          console.log('Fetched courses:', data);
          this.courseDetailProjection = data;
          this.cdr.detectChanges();
        },
        error: (err) =>{
          this.error  =err.message;
          this.cdr.detectChanges();  
        }
      });
    }
  }

  onclick(courseId: number){
    if(courseId) {
      this.router.navigate(['/course-content', courseId]);
    } else {
      console.error('Course ID is undefined');
    }
  }
}
