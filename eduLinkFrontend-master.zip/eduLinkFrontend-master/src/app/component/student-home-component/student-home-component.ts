import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StudentEnrolledCourseComponent } from "../student-enrolled-course-component/student-enrolled-course-component";
import { CourseService } from '../../service/course-service';
import { AuthService } from '../../service/auth-service';
import { FeedbackService } from '../../service/feedback-service';

@Component({
  selector: 'app-student-home-component',
  imports: [StudentEnrolledCourseComponent],
  templateUrl: './student-home-component.html',
  styleUrl: './student-home-component.css',
})
export class StudentHomeComponent implements OnInit {
  
  // --- UI State Variables ---
  enrolledCoursesCount = 0;
  upcomingExamsCount = 0; // Added to fix HTML error
  attendancePercentage = 94;
  performanceScore = 88.5;
  
  recentFeedbacks: any[] = []; // Added to hold the feedback data
  error: string = ""; // Added to fix TS2339 error

  constructor(
    private courseService: CourseService, 
    private authService: AuthService,
    private feedbackService: FeedbackService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    const studentId = this.authService.getUserId();
    
    if (studentId) {
      // 1. Fetch Enrolled Courses
      this.courseService.findCourseListByStudentId(studentId).subscribe({
        next: (courses) => {
          this.enrolledCoursesCount = courses.length;
          this.cdr.detectChanges();
          console.log('Enrolled Courses Count:', this.enrolledCoursesCount);
        },
        error: (err) => {
          console.error('Error fetching courses:', err);
        }
      });

      // 2. Fetch Recent Feedback (You missed this call previously!)
      this.loadRecentFeedback();
    }
  }

  loadRecentFeedback() {
    const userId = Number(this.authService.getUserId());
    
    if (!userId) return;

    this.feedbackService.findFeedBackList().subscribe({
      next: (allFeedback: any[]) => {
        // Filter it for this specific student
        const userFeedback = allFeedback.filter(
          (f) => f.appUserRoleId === userId
        );
        
        // FIX: Assign to the array variable, not the method name
        this.recentFeedbacks = userFeedback.slice(0, 4); 
        this.cdr.detectChanges(); 
      },
      error: (err) => {
        console.error('Could not load feedback', err);
        this.error = "Could not load recent feedback.";
        this.cdr.detectChanges();
      }
    });
  }
}