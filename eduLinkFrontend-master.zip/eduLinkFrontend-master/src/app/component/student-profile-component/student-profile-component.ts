import { Component, signal} from '@angular/core';
import { StudentDetailByIdDto } from '../../model/StudentDetailByIdDto.model';
import { StudentService } from '../../service/student-service';
import { AuthService } from '../../service/auth-service';

@Component({
  selector: 'app-student-profile-component',
  imports: [],
  templateUrl: './student-profile-component.html',
  styleUrl: './student-profile-component.css',
})
export class StudentProfileComponent {

  studentDetailByIdDto=signal<StudentDetailByIdDto | null> (null);
  error: string= '';

  constructor(private studentService:StudentService,private authService:AuthService){};

  ngOnInit() {

    const studentId = this.authService.getUserId();
    if (studentId === null) return;
    this.studentService.findStudentDetailByStudentId(studentId).subscribe({
      next: (data)=>{
        this.studentDetailByIdDto.set(data);
      },
      error: (e)=>{
        this.error = e.message;
      }
    });
  }
}
