import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-student-side-component',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './student-side-component.html',
  styleUrl: './student-side-component.css',
})
export class StudentSideComponent {
  
}
