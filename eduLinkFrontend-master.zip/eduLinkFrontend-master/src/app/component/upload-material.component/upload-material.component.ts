import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, Location } from '@angular/common'; // 1. Added Location and CommonModule
import { ActivatedRoute, Router } from '@angular/router';
import { LearningMaterialService } from '../../service/learningmaterial-service';
@Component({
  selector: 'app-upload-material.component',
  standalone:true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './upload-material.component.html',
  styleUrl: './upload-material.component.css',
})
export class UploadMaterialComponent implements OnInit { 
  uploadForm!: FormGroup;
  selectedFile: File | null = null;
  courseId!: number;
  isUploading = false;

  constructor(
    private readonly fb: FormBuilder,
    private readonly materialService: LearningMaterialService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly location: Location // 3. Injected Location here
  ) {}

  ngOnInit() {
    // Get courseId from URL params (e.g., /upload-material/1210651)
    this.courseId = Number(this.route.snapshot.paramMap.get('id'));

    this.uploadForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(150)]]
    });
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }
  onCancel() {
    this.location.back(); // 4. This will now work!
  }
  onSubmit() {
    if (this.uploadForm.valid && this.selectedFile && this.courseId) {
      this.isUploading = true;
      
      this.materialService.uploadMaterial(
        this.uploadForm.value.title,
        this.selectedFile,
        this.courseId
      ).subscribe({
        next: (response) => {
          alert(response);
          this.location.back();
        },
        error: (err) => {
          console.error(err);
          alert('Upload failed. Ensure the file size is within limits.');
          this.isUploading = false;
        }
      });
    }
  }
}