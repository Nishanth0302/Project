export interface CourseAttendanceProjection{
    courseId: number;
    courseTitle: string;
    attendancePercentage: number;
    lastAttendanceDate?: string;
}