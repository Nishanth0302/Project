export interface CourseDetailProjection {
    courseId:number;
    courseTitle:string;
    courseGradeLevel:string;
    courseRating:number;
}