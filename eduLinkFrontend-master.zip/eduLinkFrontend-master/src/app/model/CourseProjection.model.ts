export interface CourseProjection{
    courseId:number;
    courseTitle:string;
    courseSubject:string;
    courseGradeLevel:string;
    courseCredit:number;
    // courseDescription:string;
    courseStatus:string;
    courseRating:number;
}

export interface CourseDetail extends CourseProjection {
    facultyName: string;
    facultyRating: number;
    facultyYearOfExperience: number;
    description:string;
    lastUpdated?: string;
    language?: string;
    price?: number;
    reviewCount?: number;
    studentCount?: number;
    videoHours?: number;
    articles?: number;
    sections?: CourseSection[];
    learningOutcomes?: LearningOutcome[];
}

export interface CourseSection {
    sectionId: number;
    sectionTitle: string;
    lectureCount: number;
    duration: string;
    lectures: Lecture[];
}

export interface Lecture {
    lectureId: number;
    lectureTitle: string;
    duration: string;
    isCompleted: boolean;
}

export interface LearningOutcome {
    outcomesId: number;
    title: string;
    description: string;
    icon: string;
}
