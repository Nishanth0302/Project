export interface CourseRegistrationDto {
    courseTitle: string;
    courseSubject: string;
    courseGradeLevel: string; // "9" | "10" | "11" | "12" | "K" | "Undergrad"
    courseCredit: number;
    courseDescription: string;
    facultyId: number;
}