export interface FacultyDetailByIdDto{
    facultyId: number;
    facultyName: string;
    facultyEmail: string;
    facultyPhoneNumber: string;
    facultyGender: string;
    facultyYearOfExperience: number;
    facultyAddress: string;
    facultyRating: number;
}