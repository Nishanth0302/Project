export interface FacultySignUpDto {
  userName: string;
  userEmail: string;
  phoneNumber: number;
  facultyGender: 'Male' | 'Female' | 'Other';
  facultyAddress: string;
  facultyYearOfExperience: number;
  password: string;
}
