export interface FeedbackDto {
  appUserRoleId: number;
  reviewerType: string; // 'STUDENT' or 'FACULTY'
  rating: number;
  comment: string;
  
}