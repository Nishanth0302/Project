export interface FeedbackProjection{
    appUserName:string;
    message:string;
    rating:number;
}