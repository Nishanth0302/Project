export interface GradeDetailsByStudentIdDto {
  courseId: number;
  score: number;
  grade: string;
}