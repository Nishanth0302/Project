export interface StudentDetailByIdDto {
  studentName: string;
  studentEmail: string;
  studentNumber: number;
  studentId: number;
  studentDOB: string;
  studentGender: string;
  studentAddress: string;
  studentEnrollmentDateTime: string;
}