export interface StudentSignUpDto {
  userName: string;
  userEmail: string;
  phoneNumber: number;
  studentDOB: string; // yyyy-MM-dd
  studentGender: 'Male' | 'Female' | 'Other' | 'Prefer not to say';
  studentAddress: string;
  password: string;
}