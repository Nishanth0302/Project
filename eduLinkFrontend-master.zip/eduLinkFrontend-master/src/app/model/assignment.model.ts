export interface AssignmentStatus {
  id: number;
  assignmentId: number;
  assignmentTitle: string;
  pdfUrl?: string; // Optional: if you have a link to the PDF
  completed: boolean;
}