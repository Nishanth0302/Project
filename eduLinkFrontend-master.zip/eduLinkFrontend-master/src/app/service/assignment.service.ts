import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AssignmentStatus } from '../model/assignment.model';

@Injectable({
  providedIn: 'root'
})
export class AssignmentService {
  private baseUrl = 'http://localhost:8081/assignment'; // Adjust to your actual API gateway/port

  constructor(private http: HttpClient) {}

  getAssignments(courseId: number, studentId: number): Observable<AssignmentStatus[]> {
    const params = new HttpParams().set('studentId', studentId.toString());
    return this.http.get<AssignmentStatus[]>(`${this.baseUrl}/course/${courseId}`, { params });
  }

  completeAssignment(assignmentId: number, studentId: number): Observable<string> {
    const params = new HttpParams().set('studentId', studentId.toString());
    // Since your backend returns a plain string ("Assignment Completed"), use responseType: 'text'
    return this.http.post(`${this.baseUrl}/${assignmentId}/complete`, null, { params, responseType: 'text' });
  }

  checkExamAccess(courseId: number, studentId: number): Observable<boolean> {
    const params = new HttpParams().set('studentId', studentId.toString());
    return this.http.get<boolean>(`${this.baseUrl}/course/${courseId}/exam-access`, { params });
  }
}