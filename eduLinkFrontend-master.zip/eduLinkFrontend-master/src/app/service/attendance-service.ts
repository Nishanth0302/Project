import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CourseAttendanceProjection } from '../model/CourseAttendanceProjection.model';
import { Observable } from 'rxjs';

/**
 * Interface for the attendance registration request.
 * Matches your Spring Boot @RequestBody AttendanceRegistrationDto.
 */
export interface AttendanceRegistrationDto {
  studentId: number;
  courseId: number;
}

@Injectable({
  providedIn: 'root',
})
export class AttendanceService {
  // Base URL for the attendance microservice
  private readonly url: string = "http://localhost:8081/attendance";

  constructor(private readonly http: HttpClient) { }

  /**
   * Fetches attendance statistics for a specific student.
   * Ensure your backend Projection now includes the 'lastAttendanceDate' field.
   */
  findAttendanceDetailsByStudentId(studentId: number): Observable<CourseAttendanceProjection[]> {
    return this.http.get<CourseAttendanceProjection[]>(
      `${this.url}/attendanceDetailsByStudentId/${studentId}`
    );
  }

  /**
   * Posts a new attendance record for a student in a specific course.
   * Uses { responseType: 'text' } because your Spring Boot controller returns a String.
   */
  registerAttendanceByStudentId(dto: AttendanceRegistrationDto): Observable<string> {
    return this.http.post(`${this.url}/register`, dto, {
      responseType: 'text'
    });
  }
}