import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { tap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'auth_token';

  constructor(private readonly http: HttpClient, private readonly router: Router) {}

  login(credentials: any) {

    return this.http.post<{token: string}>('http://localhost:8081/auth/login', credentials).pipe(
      tap(res => localStorage.setItem(this.TOKEN_KEY, res.token))
    );
  }

  getRole(): string | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = token.split('.')[1];
      const decodedJson = atob(payload);
      const decodedToken = JSON.parse(decodedJson);
      return decodedToken.role;
    } catch (e) {
      return null;
    }
  }

  getUserId(): number | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.appUserId;
    } catch (e) {
      return null;
    }
  }

  logout() {
    localStorage.removeItem(this.TOKEN_KEY);
    this.router.navigate(['/']);
  }

  getToken() {
    const token = localStorage.getItem(this.TOKEN_KEY);
    console.log('Getting token from localStorage:', token ? 'Token exists' : 'No token found');
    return token;
  }

  isLoggedIn(): boolean {
    const loggedIn = !!this.getToken();
    console.log('Is logged in:', loggedIn);
    return loggedIn;
  }
}