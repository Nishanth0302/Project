import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CourseProjection, CourseDetail } from '../model/CourseProjection.model';
import { CourseDetailProjection } from '../model/CourseDetailProjection.model';
import { CourseRegistrationDto } from '../model/CourseRegistration.model';

@Injectable({
  providedIn: 'root',
})
export class CourseService {

  url = "http://localhost:8081/course";
  totalEnrolledCourses = 0;
  coursedetailProjection: Observable<CourseDetailProjection[]> = new Observable<CourseDetailProjection[]>();
  
  constructor(private readonly http: HttpClient) {}
  
  findAllAvailableCourse(): Observable<CourseProjection[]> {
    return this.http.get<CourseProjection[]>(`${this.url}/findAllAvailableCourse`);
  }

  findCourseListByStudentId(studnetId: number): Observable<CourseDetailProjection[]> {
    this.coursedetailProjection = this.http.get<CourseDetailProjection[]>(`${this.url}/allCourseListByStudentId/${studnetId}`);
    return this.coursedetailProjection;
  }

  getCoursesByFacultyId(facultyId: number): Observable<CourseProjection[]> {
    return this.http.get<CourseProjection[]>(`${this.url}/getCoursesByFacultyId/${facultyId}`);
  }

  findCourseDetailsById(courseId: number): Observable<CourseDetail> {  
    const url = `${this.url}/findCourseDetailsById/${courseId}`;
    console.log('Calling API:', url);
    return this.http.get<CourseDetail>(url);
  }

  enrollCourse(courseId: number, studentId: number): Observable<any> {
    return this.http.post(`${this.url}/enrollmentRequest`, { courseId, studentId }, { responseType: 'text' as const });
  }

  getFacultyCourseCount(facultyId: number): Observable<number> {
    return this.http.get<number>(`${this.url}/courseCount/${facultyId}`);
  }
  registerCourse(courseData: CourseRegistrationDto): Observable<string> {
    return this.http.post(`${this.url}/register`, courseData, { 
      responseType: 'text' 
    });
  }
  deleteCourse(courseId: number): Observable<string> {
  return this.http.delete(`${this.url}/delete/${courseId}`, { 
    responseType: 'text' 
  });
}
}
