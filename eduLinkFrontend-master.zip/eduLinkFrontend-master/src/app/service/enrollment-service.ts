import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class EnrollmentService {
  // Ensure there is no trailing slash if your method adds a slash
  private readonly url = "http://localhost:8081/student-course-assignment";
    
  constructor(private readonly http: HttpClient) {}

  /**
   * Checks if a student is enrolled in a specific course.
   * @param studentId The ID of the student
   * @param courseId The ID of the course
   * @returns An Observable emitting true if enrolled, false otherwise.
   */
  checkEnrollment(studentId: number, courseId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.url}/checkEnrollment/${studentId}/${courseId}`);
  }
}