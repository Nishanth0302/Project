import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FacultyDetailByIdDto } from '../model/FacultyDetailByIdDto.model';
import { FacultySignUpDto } from '../model/FacultySignUpDto.model';

@Injectable({
  providedIn: 'root',
})
export class FacultyService {

  url = 'http://localhost:8081/faculty';

  constructor(private http: HttpClient) { }

  getFacultyDetailsByFacultyId(facultyId: number):Observable<FacultyDetailByIdDto> {
    return this.http.get<FacultyDetailByIdDto>(`${this.url}/getFacultyDetailsByFacultyId/${facultyId}`);
  }


  registerFaculty(facultySignUpDto:FacultySignUpDto):Observable<string>{
    return this.http.post<string>(`${this.url}/register`,facultySignUpDto,{ responseType: 'text' as 'json'});
  }

  //  @PostMapping("/register")
  //   public ResponseEntity<String> registerFaculty(@Valid @RequestBody FacultyRegistrationDto facultyRegistrationDto){
  //       log.info("{} has initiated the registration as a Faculty",facultyRegistrationDto.getUserEmail());
  //       return ResponseEntity.status(200).body(facultyService.registerFaculty(facultyRegistrationDto));
  //   }

}
