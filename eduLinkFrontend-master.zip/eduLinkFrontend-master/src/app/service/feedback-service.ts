import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FeedbackProjection } from '../model/FeedbackProjection.model';
import { Observable } from 'rxjs';
import { FeedbackDto } from '../model/FeedbackDto';

@Injectable({
  providedIn: 'root',
})
export class FeedbackService {
  private readonly url= "http://localhost:8081/feedback";
  constructor(private http:HttpClient){};

  findFeedBackList():Observable<FeedbackProjection[]>{
    return this.http.get<FeedbackProjection[]>(`${this.url}/getFeedbackList`);
  }
  registerFeedback(feedback: FeedbackDto): Observable<string> {
    return this.http.post(`${this.url}/register`, feedback, { responseType: 'text' });
  }
}
