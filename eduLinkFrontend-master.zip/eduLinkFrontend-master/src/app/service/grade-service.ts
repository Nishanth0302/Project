import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GradeDetailsByStudentIdDto } from '../model/GradeDetailsByStudentIdDto.model';

export interface GradeRegistration {
  studentId: number;
  courseId: number;
}

export interface StudentGradeProjection {
  score: number;
  grade: string;
}

@Injectable({ providedIn: 'root' })
export class GradeService {
  private readonly BASE_URL = 'http://localhost:8081/grade';

  constructor(private readonly http: HttpClient) {}

  registerGrade(gradeRegistration: GradeRegistration): Observable<string> {
    return this.http.post(`${this.BASE_URL}/register`, gradeRegistration, {
      responseType: 'text'
    }) as Observable<string>;
  }

  getTotalGrade(studentId: number, courseId: number): Observable<StudentGradeProjection> {
    return this.http.get<StudentGradeProjection>(`${this.BASE_URL}/totalGrade/${studentId}/${courseId}`);
  }
  findAllGradesByStudentId(studentId: number): Observable<GradeDetailsByStudentIdDto[]> {
    return this.http.get<GradeDetailsByStudentIdDto[]>(`${this.BASE_URL}/allGrades/${studentId}`);
  }
}
