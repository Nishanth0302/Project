import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class LearningMaterialService {

  url = "http://localhost:8081/learningMaterial";
 constructor(private readonly http: HttpClient) {}
  uploadMaterial(title: string, file: File, courseId: number): Observable<string> {
    const formData = new FormData();
    formData.append('learningMaterialTitle', title);
    formData.append('learningMaterialFile', file);
    formData.append('courseId', courseId.toString());

    return this.http.post(`${this.url}/register`, formData, {
      responseType: 'text' // Because backend returns ResponseEntity<String>
    });
  }
  getCourseMaterials(courseId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}/findCourseMaterial/${courseId}`);
  }

  getLearningMaterialContent(materialId: number): Observable<Blob> {
    return this.http.get(`${this.url}/displayLearningMaterialContent/${materialId}`, { responseType: 'blob' });
  }
}