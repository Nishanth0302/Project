import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StudentDetailByIdDto } from '../model/StudentDetailByIdDto.model';
import { StudentSignUpDto } from '../model/StudentSignUpDto.model';

@Injectable({
  providedIn: 'root',
})
export class StudentService {

  url = 'http://localhost:8081/student';

  constructor(private http: HttpClient) { }

  findStudentDetailByStudentId(studentId: number): Observable<StudentDetailByIdDto> {
    return this.http.get<StudentDetailByIdDto>(`${this.url}/findStudentDetailByStudentId/${studentId}`);
  }

 
  studentRegistration(studentSignUpDto: StudentSignUpDto): Observable<string> {
    return this.http.post<string>(`${this.url}/register`,studentSignUpDto,{ responseType: 'text' as 'json'}  )
  }
}
